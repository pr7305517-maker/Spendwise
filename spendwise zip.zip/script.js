function addExpense(){
const name=document.getElementById("name").value;
const amount=document.getElementById("amount").value;

const li=document.createElement("li");
li.textContent=name+" - ₹"+amount;

document.getElementById("list").appendChild(li);
}
